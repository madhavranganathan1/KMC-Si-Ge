#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "KMCheteroepitaxy.h"
#include "funcdecl.h"
void outputprint(int Timestep)     /* This program prints the result into a file */
{
	/*FILE *outfiledispType; */
	
	/*
	char outfilename[256];
	
	sprintf(outfilename,"AtomdisplType%d",Timestep);
	outfiledispType = fopen(outfilename,"w");  */

	/*fwrite(displacementType,sizeof(struct dT), (Nx*Ny*Nz),outfiledispType);
	fwrite(Height,sizeof(int),Nx*Ny,outfileHeight);
	*/
	
	printf("if you see this, there is something wrong\n");
	
	/*fclose(outfiledispType); 
	*/
}/* End of output print. I have kept it fairly simple here. This can be modified to suit standard graphic packages. */	
