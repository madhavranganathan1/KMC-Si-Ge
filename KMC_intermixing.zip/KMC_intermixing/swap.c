
double swap(int a, int b, int c, int d , int e , int f)

{
double g ,h,i;
displacementType[a][b][c].Type=2;
displacementType[d][e][f].Type=1;
g=chemical_bond(2,a,b,c);
h=chemical_bond(1,d,e,f);
i=g+h;



return (i);

}
