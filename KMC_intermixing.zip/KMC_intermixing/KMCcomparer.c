
#include "variables.h"

int KMCcomparer(double bondenergy,int Atomx,int Atomy, int Atomz,double initenergy) 
{
     printf("This part using the slower KMC has not been written yet\n");

     return 0;

}
