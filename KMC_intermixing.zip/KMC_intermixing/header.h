
#include <stdio.h>
#include <stdlib.h>

#include "variables.h"
int CHK=0;

#include <math.h>
#include "routinedecl.h"
#include "my_f.c"
#include "my_df.c"
#include "my_fdf.c"
#include "my_fthomas.c" 
#include "my_dfthomas.c" 
#include "my_fdfthomas.c" 
#include "allsubfunctions.h"
